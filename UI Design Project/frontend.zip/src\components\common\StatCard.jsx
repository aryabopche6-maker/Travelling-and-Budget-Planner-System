import React from 'react';

export const StatCard = ({ title, value, subtext, icon: Icon, trend, trendValue, color = 'brand' }) => {
  return (
    <div className="glass-panel p-5 rounded-2xl border border-slate-800/80 hover:border-slate-700/80 transition-all duration-200">
      <div className="flex items-center justify-between">
        <span className="text-xs font-semibold uppercase tracking-wider text-slate-400 dark:text-slate-400 light:text-slate-500">
          {title}
        </span>
        {Icon && (
          <div className={`p-2.5 rounded-xl bg-slate-800/80 text-brand-400`}>
            <Icon className="w-5 h-5" />
          </div>
        )}
      </div>
      <div className="mt-3 flex items-baseline justify-between">
        <span className="text-3xl font-extrabold tracking-tight text-white dark:text-white light:text-slate-900">
          {value}
        </span>
        {trendValue && (
          <span className={`inline-flex items-center text-xs font-medium ${
            trend === 'up' ? 'text-emerald-400' : trend === 'down' ? 'text-rose-400' : 'text-slate-400'
          }`}>
            {trend === 'up' ? '↑' : trend === 'down' ? '↓' : '•'} {trendValue}
          </span>
        )}
      </div>
      {subtext && (
        <p className="mt-1.5 text-xs text-slate-400 dark:text-slate-400 light:text-slate-600">
          {subtext}
        </p>
      )}
    </div>
  );
};
