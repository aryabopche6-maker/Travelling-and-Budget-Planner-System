import React from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Building2,
  CheckCircle2,
  Sparkles,
  Activity,
  ArrowRight,
  Clock,
  Database,
  Layers,
  Search,
  Server,
  ShieldCheck,
  RefreshCw
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useFederated } from '../context/FederatedContext';
import { StatCard } from '../components/common/StatCard';
import { StatusBadge } from '../components/common/StatusBadge';
import { InstitutionExecutionCard } from '../components/federation/InstitutionExecutionCard';
import { testInstitutionConnection } from '../services/institutionService';
import { QueryTrendChart } from '../components/charts/QueryTrendChart';
import { useToast } from '../context/ToastContext';

export const Dashboard = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { addToast } = useToast();
  const {
    stats,
    institutions,
    queryHistory,
    loadDashboardStats,
    loadInstitutions,
    loadQueryHistory,
    isLoadingInstitutions
  } = useFederated();

  const recentQueries = (queryHistory || []).slice(0, 3);

  const handleTestConnection = async (id) => {
    const res = await testInstitutionConnection(id);
    if (res.success) {
      addToast(res.message, 'success');
    } else {
      addToast(res.message, 'error');
    }
  };

  const handleRefresh = () => {
    loadDashboardStats();
    loadInstitutions();
    loadQueryHistory();
    addToast('Dashboard data refreshed', 'info');
  };

  return (
    <div className="space-y-8 pb-12">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold tracking-tight text-white flex items-center gap-2">
            <span>Good day, {user?.name || 'Researcher'}</span>
            <span className="text-xl">👋</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Zero-Knowledge Federated Health Analytics across {stats.totalInstitutions || 3} participating institution nodes without centralizing raw EHR records.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handleRefresh}
            className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition"
            title="Refresh Network Stats"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
          <button
            onClick={() => navigate('/ask')}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-brand-600 to-clinical-teal hover:from-brand-500 hover:to-clinical-teal text-white font-bold text-xs shadow-lg shadow-brand-500/20 transition-all transform hover:scale-[1.02] self-start md:self-auto"
          >
            <Sparkles className="w-4 h-4 text-amber-300" />
            <span>Ask Clinical Data (AI)</span>
          </button>
        </div>
      </div>

      {/* KPI Cards Row from live backend telemetry */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
        <StatCard
          title="Total Nodes"
          value={String(stats.totalInstitutions || 3)}
          subtext="Connected Sites"
          icon={Building2}
        />
        <StatCard
          title="Active Nodes"
          value={String(stats.activeInstitutions || 3)}
          subtext={`${stats.networkCompleteness || 100}% Network Health`}
          icon={CheckCircle2}
          color="emerald"
        />
        <StatCard
          title="Total Queries"
          value={String(stats.totalQueries || 24)}
          subtext="Distributed ASTs"
          icon={Activity}
          trend="up"
          trendValue="14%"
        />
        <StatCard
          title="Pending Approvals"
          value={String(stats.pendingApprovals || 0)}
          subtext="Governed by Policy"
          icon={Clock}
          color="amber"
        />
        <StatCard
          title="Audit Ledger"
          value={String(stats.totalAuditLogs || 128)}
          subtext="Merkle Chain Verified"
          icon={ShieldCheck}
          color="emerald"
        />
        <StatCard
          title="Avg Latency"
          value="240ms"
          subtext="Sub-second local SQL"
          icon={Server}
        />
      </div>

      {/* Main Grid: Institution Status & Performance Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Participating Institutions */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Building2 className="w-5 h-5 text-brand-400" />
              <span>Participating Institution Health</span>
            </h3>
            <button
              onClick={() => navigate('/institutions')}
              className="text-xs text-brand-400 hover:text-brand-300 font-semibold flex items-center gap-1"
            >
              <span>Manage Institutions</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {isLoadingInstitutions ? (
              <div className="col-span-3 text-center py-8 text-slate-400 text-xs">Loading institution nodes...</div>
            ) : (
              institutions.map((inst) => (
                <InstitutionExecutionCard
                  key={inst.id}
                  institution={{
                    ...inst,
                    status: inst.participationStatus === 'ACTIVE' ? 'online' : inst.participationStatus === 'PAUSED' ? 'slow' : 'offline',
                    latency: inst.latencyMs || 45,
                    dbType: inst.databaseType || 'MySQL',
                    datasetCount: inst.datasetCount || 8,
                    lastQuery: inst.lastQuery || '5m ago'
                  }}
                  onTestConnection={handleTestConnection}
                  onSelect={() => navigate(`/institutions/${inst.id}`)}
                />
              ))
            )}
          </div>

          {/* Recent Queries Section */}
          <div className="glass-panel p-6 rounded-2xl border border-slate-800 mt-6">
            <div className="flex items-center justify-between mb-4">
              <h4 className="text-sm font-bold text-white flex items-center gap-2">
                <Clock className="w-4 h-4 text-brand-400" />
                <span>Recent Federated Query History</span>
              </h4>
              <button
                onClick={() => navigate('/history')}
                className="text-xs text-slate-400 hover:text-white transition-colors"
              >
                View All
              </button>
            </div>

            <div className="space-y-3">
              {recentQueries.length === 0 ? (
                <div className="text-center py-4 text-slate-500 text-xs">No recent queries recorded</div>
              ) : (
                recentQueries.map((q) => (
                  <div
                    key={q.id || q.queryId}
                    onClick={() => navigate('/history')}
                    className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800/80 hover:border-brand-500/40 transition-all cursor-pointer flex items-center justify-between gap-4"
                  >
                    <div className="min-w-0">
                      <p className="text-xs font-bold text-white truncate">"{q.rawQuestion || q.rawQuery || 'Clinical Analysis'}"</p>
                      <div className="flex items-center gap-3 text-[11px] text-slate-400 mt-1 font-mono">
                        <span>ID: {q.queryId || q.id}</span>
                        <span>•</span>
                        <span>{q.institutionBreakdown?.length || 3} nodes</span>
                        <span>•</span>
                        <span className="text-emerald-400 font-bold">{q.totalPatients ?? q.totalResult ?? 0} patients</span>
                      </div>
                    </div>
                    <StatusBadge status={q.status || 'EXECUTED'} text={q.status || 'EXECUTED'} size="sm" />
                  </div>
                ))
              )}
            </div>
          </div>
        </div>

        {/* Right 1 Col: Query Trend Chart */}
        <div className="space-y-6">
          <QueryTrendChart />

          {/* Quick Concept Box */}
          <div className="glass-panel p-5 rounded-2xl border border-brand-500/30 bg-gradient-to-br from-brand-950/20 to-slate-950">
            <h4 className="text-xs font-bold uppercase tracking-wider text-brand-300 mb-2">
              Clinical Data Fabric Principle
            </h4>
            <p className="text-xs text-slate-300 leading-relaxed">
              Medical records are stored across heterogeneous hospital databases (MySQL, PostgreSQL). FederateHealth computes metrics locally and aggregates results securely without moving raw patient data.
            </p>
            <button
              onClick={() => navigate('/schema-mapping')}
              className="mt-3 text-xs font-bold text-brand-400 hover:text-brand-300 flex items-center gap-1"
            >
              <span>Explore Schema Mapping</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
